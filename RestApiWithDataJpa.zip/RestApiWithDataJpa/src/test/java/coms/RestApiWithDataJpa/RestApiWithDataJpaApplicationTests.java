package coms.RestApiWithDataJpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestApiWithDataJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
