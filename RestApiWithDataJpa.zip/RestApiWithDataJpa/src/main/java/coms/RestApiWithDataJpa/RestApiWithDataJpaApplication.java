package coms.RestApiWithDataJpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestApiWithDataJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestApiWithDataJpaApplication.class, args);
	}

}
