package com.xwiggy.food;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XwiggyApplication {

    public static void main(String[] args) {
        SpringApplication.run(XwiggyApplication.class, args);
    }

}
