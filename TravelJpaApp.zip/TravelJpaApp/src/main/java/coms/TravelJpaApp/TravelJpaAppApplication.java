package coms.TravelJpaApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelJpaAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(TravelJpaAppApplication.class, args);
	}

}
