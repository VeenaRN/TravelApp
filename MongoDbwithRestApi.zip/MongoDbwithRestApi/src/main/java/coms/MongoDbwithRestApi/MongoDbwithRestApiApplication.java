package coms.MongoDbwithRestApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MongoDbwithRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MongoDbwithRestApiApplication.class, args);
	}

}
