package coms.SpringDataJpaApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataJpaAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
